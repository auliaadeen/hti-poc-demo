"""
Quick standalone test for LlamaParse — run this BEFORE wiring into the app,
to confirm your API key works and see raw output quality on a real HTI
document (invoice, PO, packing list, etc).

Setup:
    pip install llama-cloud
    export LLAMA_CLOUD_API_KEY="your-key-here"

Usage:
    python3 test_llamaparse.py /path/to/document.pdf
"""

import sys
import os

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 test_llamaparse.py /path/to/document.pdf")
        sys.exit(1)

    api_key = os.environ.get("LLAMA_CLOUD_API_KEY")
    if not api_key:
        print("ERROR: set LLAMA_CLOUD_API_KEY environment variable first.")
        print('  export LLAMA_CLOUD_API_KEY="your-key-here"')
        sys.exit(1)

    file_path = sys.argv[1]

    # llama-cloud is the current (non-deprecated) SDK. Check
    # https://developers.llamaindex.ai/llamaparse for the latest client
    # usage if this import path has changed since.
    from llama_cloud.client import LlamaCloud

    client = LlamaCloud(token=api_key)

    print(f"Uploading {file_path} to LlamaParse...")
    with open(file_path, "rb") as f:
        job = client.parsing.upload_file(file=f)

    print(f"Job ID: {job.id} — waiting for result...")
    result = client.parsing.get_job_result(job_id=job.id, result_type="markdown")

    print("\n--- PARSED MARKDOWN OUTPUT ---\n")
    print(result.markdown[:3000])
    print("\n--- (truncated if longer than 3000 chars) ---")


if __name__ == "__main__":
    main()
